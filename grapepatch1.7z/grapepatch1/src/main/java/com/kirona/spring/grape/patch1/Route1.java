package com.kirona.spring.grape.patch1;

import org.apache.camel.ExchangePattern;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.CsvDataFormat;
import org.springframework.stereotype.Component;

import com.kirona.kironadata.data.model.SetRefCodesRequest;
import com.kirona.spring.soap.jm.JmClient;

@Component
public class Route1 extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    // in reality, you might pattern match the filenames rather than using the choice() stuff ... this is just a POC
    from("file://app/kirona/files/csv?autoCreate=true&readLock=rename&move=done&antInclude=*.txt")
      .tracing()
      // https://camel.apache.org/components/3.7.x/file-component.html#_file_consumer_only
      // https://camel.apache.org/manual/latest/faq/why-can-i-not-use-when-or-otherwise-in-a-java-camel-route.html
      .setProperty("orgCode").constant("KIR1") // different folders per org ?
      .choice()
        .when(header("CamelFileNameOnly").startsWith("refcodes"))
          .to("direct:patch1.file.refcodes")
        .otherwise()
          .log("Not a known file pattern : ${header.CamelFilePath}")
        .end();


    CsvDataFormat csvFormat = new CsvDataFormat();
    csvFormat.setDelimiter(",");
    csvFormat.setIgnoreHeaderCase("true");
    csvFormat.setSkipHeaderRecord("true"); // header is not data
    csvFormat.setUseMaps("true"); // file must have a header row
    
    // etc
    
    from("direct:patch1.file.refcodes")
      .log("Importing as RefCodes : ${header.CamelFilePath}")
      .unmarshal(csvFormat)  // one big list of maps !
      .convertBodyTo(SetRefCodesRequest.class) // relies on the translator below
      .setExchangePattern(ExchangePattern.InOnly)
      .bean(JmClient.class, "setRefCodes(${body},${exchangeProperty.orgCode})");
    
  }

}
